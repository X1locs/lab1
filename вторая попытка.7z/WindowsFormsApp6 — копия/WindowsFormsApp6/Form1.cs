﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox1.Text = Properties.Settings.Default.price;
            textBox2.Text = Properties.Settings.Default.result;
        }

        public class Logic
        {
            public static string Compare(int price, int rub, int kop)
            {
                string outMessage = " ";
                if ((price <= 0) || (price >= 10000))
                {
                    outMessage = "Вы ввели стоимость товара не в промежутке [1;9999]";
                }
                else
                {
                    string str = " рублей";
                    if (rub % 10 == 1 && rub != 11) str = " рубль";
                    if ((rub % 10 >= 2 && rub % 10 <= 4) && (rub != 13 && rub != 14 && rub != 12)) str = " рубля";

                    string str1 = " копеек";
                    if (kop % 10 == 1 && kop != 11) str1 = " копейка";
                    if ((kop % 10 >= 2 && kop % 10 <= 4) && (kop != 13 && kop != 14 && kop != 12)) str1 = " копейки";

                    if ((rub != 0) && (kop != 0))
                    {
                        outMessage += rub + " " + str + " " + kop + " " + str1;
                    }
                    else if ((kop == 0) && (rub != 0))
                    {
                        outMessage += rub + " " + str + " " + " ровно";
                    }
                    else if ((rub == 0) && (kop != 0))
                    {
                        outMessage += kop + " " + str1 + " " + " ровно";
                    }

                }
                return outMessage;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var price = int.Parse(this.textBox1.Text);
                var rub = price / 100;
                var kop = price - (rub * 100);
                string result = Logic.Compare(price, rub, kop);
                textBox2.Text = result.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Некорректный ввод", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.price = textBox1.Text;
            Properties.Settings.Default.result = textBox2.Text;

            Properties.Settings.Default.Save();
        }

    }
}
